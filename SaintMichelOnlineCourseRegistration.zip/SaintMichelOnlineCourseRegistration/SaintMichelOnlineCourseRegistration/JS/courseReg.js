﻿var courseArray = []; 
window.onload = init;

function addCourse() {

    var course = {
        code: document.getElementById("code").value,
        title: document.getElementById("title").value,
        duration: document.getElementById("duration").value,
    };

    if (course.code !== "" && course.title !== "" &&
       course.duration !== "") {
 
        courseArray = JSON.parse(localStorage.getItem("course")) || [];
        courseArray.push(course);
        localStorage.setItem("course", JSON.stringify(courseArray));
        courseArray = localStorage.getItem("course");
        courseArray = JSON.parse(courseArray);

        for (i = 0; i < courseArray.length; i++) {
            var row = assign.insertRow(1);
            var cell1 = row.insertCell(0);
            var cell2 = row.insertCell(1);
            var cell3 = row.insertCell(2);

            cell1.innerHTML = courseArray[i].code;
            cell2.innerHTML = courseArray[i].title;
            cell3.innerHTML = courseArray[i].duration;
        }
        window.location.reload(true);
    }

}
    function clearData() {
        localStorage.clear();
        window.location.reload(true);
    }

    function createCourse(course) {
        var table = document.getElementById("assigned");
        var row = document.createElement("tr");
        var cell1 = document.createElement("td");
        var cell2 = document.createElement("td");
        var cell3 = document.createElement("td");

        cell1.innerHTML = course.code;
        cell2.innerHTML = course.title;
        cell3.innerHTML = course.duration;

        row.appendChild(cell1);
        row.appendChild(cell2);
        row.appendChild(cell3);

        table.appendChild(row);
    }
   function getCourseArray(){
       return JSON.parse(localStorage.getItem("course"));
   }

   function init() {
       var courseArray = getCourseArray();
       for (i = 0; i < courseArray.length; i++) {
           var course = courseArray[i];
           createCourse(course);
       }
   }
