﻿var objStudent = [
    {
        userid: "1111111",
        password: "Mary_1234",
        firstName:"Mary",
        lastName: "Brown",
        email:"mary@yahoo.com"
    },

     {
         userid: "2222222",
         password: "Wei_1235",
         firstName: "Wei",
         lastName: "Huang",
         email:"wei@gmail.com"

     },
      {
          userid: "3333333",
          password: "Michael_1236",
          firstName: "Michael",
          lastName: "Freitag",
          email:"michael@hotmail.com"
      },
       {
           userid: "4444444",
           password: "Lisa_1237",
           firstName: "Lisa Marie",
           lastName: "Mapile",
           email:"marie@yahoo.ca"
       },
        {
            userid: "5555555",
            password: "Daniel_1238",
            firstName: "Daniel",
            lastName: "Rother",
            email:"mary@yahoo.com"
        }
]

function getInfo() {
    var userid = document.getElementById("userid").value;
    var password = document.getElementById("password").value;
    for (var i = 0; i < objStudent.length; i++) {
        if(userid==objStudent[i].userid && password==objStudent[i].password){
            alert("Successfull login, Welcome to Saint-Michel Technology Institution");
            window.open("home.html");
        }
    }
        alert("Incorrect userid or password, Please try again...");
}
